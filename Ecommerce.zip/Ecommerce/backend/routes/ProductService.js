const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const multer = require('multer');

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

const upload = multer({ storage });

// GET products by category
router.get('/category/:category', async (req, res) => {
  try {
    const category = req.params.category;
    const products = await Product.find({ category });
    res.json(products);
  } catch (error) {
    console.error('Error fetching products by category:', error);
    res.status(500).send('Server error');
  }
});

// Add a new product
router.post('/', upload.single('picture'), async (req, res) => {
  console.log('Request body:', req.body); // Log the request body
  console.log('Request file:', req.file); // Log the file info

  try {
    const { name, price, category } = req.body;
    const picture = req.file ? req.file.path : '';

    const newProduct = new Product({
      name,
      picture,
      price,
      category
    });

    await newProduct.save();
    res.status(201).json(newProduct);
  } catch (error) {
    console.error('Error adding product:', error);
    res.status(500).json({ message: 'Error adding product', error });
  }
});

// GET all products or by category
router.get('/', async (req, res) => {
  try {
    const { category } = req.query;
    const query = category ? { category: new RegExp(category, 'i') } : {};
    console.log('Query:', query); // Log query
    const products = await Product.find(query);
    console.log('Fetched products:', products); // Log fetched products
    res.status(200).json(products);
  } catch (error) {
    console.error('Error fetching products:', error); // Log error
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
