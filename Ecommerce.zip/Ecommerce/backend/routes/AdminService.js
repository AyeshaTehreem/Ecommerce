// routes/AdminService.js
const express = require('express');
const router = express.Router();
const Product = require('../models/Product'); // Adjust the path as needed
const multer = require('multer');

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

const upload = multer({ storage });

// Add a new product
router.post('/add', upload.single('picture'), async (req, res) => {
  try {
    const { name, price, category } = req.body;
    const picture = req.file ? req.file.path : '';

    const newProduct = new Product({
      name,
      picture,
      price,
      category
    });

    await newProduct.save();
    res.status(201).json(newProduct);
  } catch (error) {
    res.status(500).json({ message: 'Error adding product', error });
  }
});
// DELETE product by ID
router.delete('/:id', async (req, res) => {
  try {
    const productId = req.params.id;
    const deletedProduct = await Product.findByIdAndDelete(productId);

    if (!deletedProduct) {
      return res.status(404).json({ message: 'Product not found' });
    }

    res.status(200).json({ message: 'Product deleted successfully' });
  } catch (error) {
    console.error('Error deleting product:', error);
    res.status(500).json({ message: 'Error deleting product', error });
  }
});

// Add more admin-related routes as needed

module.exports = router;
