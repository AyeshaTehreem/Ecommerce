require('dotenv').config();
const jwt = require('jsonwebtoken');

const payload = { user: { id: 'testUserId' } };
const secret = process.env.JWT_SECRET;

if (!secret) {
    console.error('Secret is not defined');
    process.exit(1);
}

jwt.sign(payload, secret, { expiresIn: '1h' }, (err, token) => {
    if (err) {
        console.error('Error signing token:', err.message);
    } else {
        console.log('JWT Token:', token);
    }
});
