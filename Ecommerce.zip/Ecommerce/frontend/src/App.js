import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Home from './pages/Home';
import Categories from './pages/Categories'; // Import Categories page
import HomeAndAccessories from './pages/HomeAndAccessories';
import WomenAndFashion from './pages/WomenAndFashion';
import Beauty from './pages/Beauty';
import Jewelry from './pages/Jewelry';
import Watches from './pages/Watches';
import KitchenAppliances from './pages/KitchenAppliances';
import ElectronicAppliances from './pages/ElectronicAppliances';
import Men from './pages/Men';
import Cart from './pages/Cart';
import Login from './pages/login'; // Import Login component
import Signup from './pages/signup'; // Import Signup component
// index.js or App.js
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import '@fortawesome/fontawesome-free/css/all.min.css';



function App() {
  return (
    
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/categories" element={<Categories />} />
        <Route path="/home-and-accessories" element={<HomeAndAccessories />} />
        <Route path="/women-and-fashion" element={<WomenAndFashion />} />
        <Route path="/beauty" element={<Beauty />} />
        <Route path="/jewelry" element={<Jewelry />} />
        <Route path="/watches" element={<Watches />} />
        <Route path="/kitchen-appliances" element={<KitchenAppliances />} />
        <Route path="/electronic-appliances" element={<ElectronicAppliances />} />
        <Route path="/men" element={<Men />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/login" element={<Login/>} /> {/* Define route for Login */}
        <Route path="/signup" element={<Signup/>} /> {/* Define route for Signup */}
   
      </Routes>
      <ToastContainer />
    </Router>
  );
}

export default App;
