import axios from 'axios';

const API_URL = 'http://localhost:5000/api/products'; // Ensure this URL is correct

export const getProductsByCategory = async (category) => {
  try {
    const response = await axios.get(`${API_URL}/category/${category}`);
    return response.data;
  } catch (error) {
    console.error('Error fetching products by category:', error);
    throw error;
  }
};
