import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import '../App.css'; // Import your CSS file

const Navbar = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <nav className="bg-gray-800" role="navigation">
      <div className="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8">
        <div className="relative flex items-center justify-between h-16">
          {/* Logo Section */}
          <div className="flex-shrink-0">
            <div className="text-3xl font-bold logo"> {/* Apply the logo class */}
              CartFusion
            </div>
          </div>
          {/* Navbar Links for Desktop */}
          <div className="hidden sm:flex sm:ml-auto items-center space-x-2">
            <div className="flex space-x-2">
              <Link to="/" className="navbar-link text-lg font-medium px-3 py-2 rounded-md no-underline">Home</Link>
              <Link to="/categories" className="navbar-link text-lg font-medium px-3 py-2 rounded-md no-underline">Categories</Link>
              <Link to="/about" className="navbar-link text-lg font-medium px-3 py-2 rounded-md no-underline">About</Link>
              <Link to="/contact" className="navbar-link text-lg font-medium px-3 py-2 rounded-md no-underline">Contact</Link>
              <Link to="/cart" className="navbar-link text-lg font-medium px-3 py-2 rounded-md no-underline">Cart</Link>
            </div>
            {/* Login & Signup Buttons */}
            <div className="flex space-x-2">
              <Link to="/login" className="navbar-button text-lg font-medium px-4 py-2 rounded-md no-underline">Login</Link>
              <Link to="/signup" className="navbar-button text-lg font-medium px-4 py-2 rounded-md no-underline">Signup</Link>
            </div>
          </div>
          {/* Mobile Menu Button */}
          <div className="absolute inset-y-0 right-0 flex items-center sm:hidden">
            <button
              type="button"
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
              aria-controls="mobile-menu"
              aria-expanded={mobileMenuOpen}
              onClick={toggleMobileMenu}
            >
              <span className="sr-only">Open main menu</span>
              {mobileMenuOpen ? (
                <svg
                  className="block h-6 w-6"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  aria-hidden="true"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
              ) : (
                <svg
                  className="block h-6 w-6"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  aria-hidden="true"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7" />
                </svg>
              )}
            </button>
          </div>
        </div>
      </div>
      {/* Mobile Menu */}
      <div className={`sm:hidden ${mobileMenuOpen ? 'block' : 'hidden'}`} id="mobile-menu">
        <div className="px-2 pt-2 pb-3 space-y-1">
          <Link to="/" className="navbar-link text-lg font-medium block px-4 py-2 rounded-md no-underline">Home</Link>
          <Link to="/categories" className="navbar-link text-lg font-medium block px-4 py-2 rounded-md no-underline">Categories</Link>
          <Link to="/about" className="navbar-link text-lg font-medium block px-4 py-2 rounded-md no-underline">About</Link>
          <Link to="/contact" className="navbar-link text-lg font-medium block px-4 py-2 rounded-md no-underline">Contact</Link>
          <Link to="/cart" className="navbar-link text-lg font-medium block px-4 py-2 rounded-md no-underline">Cart</Link>
          <Link to="/login" className="navbar-button text-lg font-medium block px-4 py-2 rounded-md no-underline border">Login</Link>
          <Link to="/signup" className="navbar-button text-lg font-medium block px-4 py-2 rounded-md no-underline border">Signup</Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
