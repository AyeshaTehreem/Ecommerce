import React from 'react';

const Carousel = () => {
  return (
    <div id="carouselExampleControls" className="carousel slide relative w-full h-[600px]" data-bs-ride="carousel"> {/* Adjusted height */}
      <div className="carousel-inner relative w-full h-full overflow-hidden">
        <div className="carousel-item active w-full h-full">
          <img src="/assets/img/carousel-1.jpg" className="block w-full h-full object-cover" alt="First slide" />
        </div>
        <div className="carousel-item w-full h-full">
          <img src="/assets/img/carousel-2.jpg" className="block w-full h-full object-cover" alt="Second slide" />
        </div>
        {/* Add more carousel items if needed */}
      </div>
      <button className="carousel-control-prev absolute top-0 bottom-0 left-0 flex items-center justify-center p-0 text-center border-0 hover:outline-none hover:no-underline focus:outline-none focus:no-underline" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
        <span className="carousel-control-prev-icon inline-block bg-no-repeat" aria-hidden="true"></span>
        <span className="visually-hidden">Previous</span>
      </button>
      <button className="carousel-control-next absolute top-0 bottom-0 right-0 flex items-center justify-center p-0 text-center border-0 hover:outline-none hover:no-underline focus:outline-none focus:no-underline" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
        <span className="carousel-control-next-icon inline-block bg-no-repeat" aria-hidden="true"></span>
        <span className="visually-hidden">Next</span>
      </button>
    </div>
  );
};

export default Carousel;
