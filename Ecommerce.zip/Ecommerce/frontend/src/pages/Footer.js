import React from 'react';
import { Link } from 'react-router-dom';
import Newsletter from './Newsletter';
import '@fortawesome/fontawesome-free/css/all.min.css'; // Import Font Awesome CSS
import '../App.css'; // Make sure to import your CSS file

const Footer = () => {
  // Define the variables here
  const footerContact = [
    { icon: '📞', name: '123-456-7890' },
    { icon: '✉️', name: 'info@cartfusion.com' },
  ];

  const socialIcons = [
    { icon: 'fab fa-facebook-f', link: 'https://facebook.com' },
    { icon: 'fab fa-twitter', link: 'https://twitter.com' },
    { icon: 'fab fa-instagram', link: 'https://instagram.com' },
    { icon: 'fab fa-linkedin-in', link: 'https://linkedin.com' },
  ];

  const footerItem = [
    {
      header: 'About Us',
      UnitItem: [
        { name: 'Our Story', link: '/about' },
        { name: 'Careers', link: '/careers' },
      ],
    },
    {
      header: 'Services',
      UnitItem: [
        { name: 'Shop with us', link: '/booking' },
        { name: 'Support', link: '/support' },
      ],
    },
  ];

  return (
    <>
      <Newsletter />
      <div className="bg-gray-800 text-gray-200 py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-between">
            <div className="w-full md:w-1/2 lg:w-1/3 mb-6 md:mb-0">
              <div className="bg-ufone-orange p-6 rounded-lg">
                <Link to="/" className="no-underline">
                  <h1 className="text-white text-2xl font-bold mb-4">CartFusion</h1>
                </Link>
                <p className="text-white">
                  Join us today and explore a world of possibilities with effortless shopping and seamless checkout for all your favorite products.
                </p>
              </div>
            </div>
            <div className="w-full md:w-1/3 lg:w-1/4 mb-6 md:mb-0">
              <h6 className="text-ufone-orange text-lg font-semibold mb-4">Contact</h6>
              {footerContact.map((val, index) => (
                <p className="mb-2 flex items-center" key={index}>
                  <span className="mr-2">{val.icon}</span> {val.name}
                </p>
              ))}
              <div className="flex space-x-4 mt-4">
                {socialIcons.map((val, index) => (
                  <a key={index} className="text-white hover:text-ufone-orange icon-hover" href={val.link}>
                    <i className={val.icon}></i>
                  </a>
                ))}
              </div>
            </div>
            <div className="w-full lg:w-1/3">
              <div className="flex flex-wrap">
                {footerItem.map((section, sectionIndex) => (
                  <div className="w-1/2 mb-6 lg:mb-0" key={sectionIndex}>
                    <h6 className="text-ufone-orange text-lg font-semibold mb-4">{section.header}</h6>
                    {section.UnitItem.map((item, itemIndex) => (
                      <Link className="block text-gray-200 hover:text-ufone-orange no-underline mb-2" to={item.link} key={itemIndex}>
                        {item.name}
                      </Link>
                    ))}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Footer;
