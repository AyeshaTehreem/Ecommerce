// src/pages/Cart.js
import React from 'react';
import Navbar from './Navbar';
import Footer from './Footer';
import { useCart } from './CartContext'; // Correct path
import '../App.css';
const Cart = () => {
  const { cart, removeItem } = useCart(); // Destructure cart and removeItem from the context

  if (!cart) {
    // If cart is undefined, set an empty array
    return (
      <div className="bg-gray-100 min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1 flex flex-col items-center">
          <h1 className="text-4xl font-bold text-center mt-10 text-ufone-orange">Cart</h1>
          <section className="w-full max-w-7xl px-4 sm:px-6 lg:px-8 mt-8">
            <p className="text-center text-lg text-gray-700">Loading cart...</p>
          </section>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="bg-gray-100 min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1 flex flex-col items-center">
        <h1 className="text-4xl font-bold text-center mt-10 text-ufone-orange">Cart</h1>
        <section className="w-full max-w-7xl px-4 sm:px-6 lg:px-8 mt-8">
          {cart.length === 0 ? (
            <p className="text-center text-lg text-gray-700">Your cart is empty.</p>
          ) : (
            <div className="w-full">
              <div className="bg-white p-4 rounded-lg shadow-lg">
                <h2 className="text-2xl font-bold mb-4 text-ufone-orange">Cart Items</h2>
                {cart.map((item, index) => (
                  <div key={index} className="flex justify-between items-center mb-4">
                    <div className="text-lg font-semibold">{item.name}</div>
                    <div className="flex items-center space-x-4">
                      <div className="text-gray-600">${item.price.toFixed(2)}</div>
                      <button
                        onClick={() => removeItem(item.id)} // Call removeItem with the item's id
                        className="text-ufone-orange hover:text-orange-700"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Cart;
