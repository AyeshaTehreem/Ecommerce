import React, { useEffect, useState } from 'react';
import Navbar from './Navbar';
import Footer from './Footer';
import { getProductsByCategory } from '../services/productService';
import { useCart } from './CartContext'; // Correct path
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const HomeAndAccessories = () => {
  const [products, setProducts] = useState([]);
  const { addToCart } = useCart(); // Destructure addToCart from the context
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const categoryProducts = await getProductsByCategory('Home & Accessories');
        console.log('Fetched products for Home & Accessories:', categoryProducts); // Log data
        setProducts(categoryProducts);
      } catch (error) {
        console.error('Error fetching products for Home & Accessories:', error); // Log error
      }
    };
  
    fetchProducts();
  }, []);
  
  const handleAddToCart = (item) => {
    addToCart(item);
    toast.success('Item added to cart!');
  };

  return (
    <div className="bg-gray-100 min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1 flex flex-col items-center">
        <h1 className="text-4xl font-bold text-center mt-10">Home & Accessories</h1>
        <section className="w-full max-w-7xl px-4 sm:px-6 lg:px-8 mt-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {products.map((product) => (
              <div key={product._id} className="bg-white p-4 rounded-lg shadow">
                <img src={`http://localhost:5000/${product.picture}`} alt={product.name} className="h-40 w-full object-cover rounded-t-lg" />
                <div className="mt-4">
                  <h3 className="text-lg font-semibold">{product.name}</h3>
                  <p className="text-gray-600">${product.price}</p>
                  <button
                    onClick={() => handleAddToCart(product)}
                    className="w-full bg-ufone-orange text-white rounded-full py-3 px-8 uppercase font-bold text-xs transition-transform transform active:scale-95 mt-4 hover:bg-orange-700"
                  >
                    Add to Cart
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
      <Footer />
      <ToastContainer />
    </div>
  );
};

export default HomeAndAccessories;
