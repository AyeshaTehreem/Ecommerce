import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });
  const navigate = useNavigate();

  const { email, password } = formData;

  const onChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    
    try {
        const response = await axios.post('http://localhost:5000/api/auth/login', formData);
        console.log(response.data);

        localStorage.setItem('token', response.data.token);
        navigate('/');

        toast.success('Login successful!');
    } catch (error) {
        console.error('Login error:', error.response?.data || error.message);

        if (error.response && error.response.data.errors) {
            toast.error(error.response.data.errors.map(err => err.msg).join(', '));
        } else {
            toast.error(error.response?.data?.detail || 'An unexpected error occurred');
        }
    }
};

  

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-md mx-auto bg-white rounded-lg shadow-md overflow-hidden md:max-w-md">
        <div className="md:flex">
          <div className="w-full p-3 px-6 py-10">
            <div className="text-center">
              <h1 className="text-gray-800 text-3xl font-semibold">Sign in</h1>
            </div>
            <form className="mt-8" onSubmit={onSubmit}>
              <input
                type="email"
                name="email"
                placeholder="Email"
                value={email}
                onChange={onChange}
                className="block w-full bg-gray-100 text-gray-800 border rounded-lg px-4 py-2 mb-4"
              />
              <input
                type="password"
                name="password"
                placeholder="Password"
                value={password}
                onChange={onChange}
                className="block w-full bg-gray-100 text-gray-800 border rounded-lg px-4 py-2 mb-4"
              />
              <div className="flex items-center justify-between">
                <Link to="#" className="text-sm text-gray-600 hover:underline">Forgot your password?</Link>
              </div>
              <button
                type="submit"
                className="w-full bg-ufone-orange text-white rounded-full py-3 px-8 uppercase font-bold text-xs transition-transform transform active:scale-95 mt-4 hover:bg-orange-700"
              >
                Sign In
              </button>
            </form>
            <p className="mt-4 text-gray-600">
              Don't have an account? <Link to="/signup" className="text-red-500 hover:underline">Sign Up</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
