import React from 'react';
import { Link } from 'react-router-dom';
import Navbar from './Navbar';
import Carousel from './Carousel';
import Footer from './Footer';
import '../App.css';

const Home = () => {
  const categories = [
    { name: 'Home & Accessories', path: '/home-and-accessories', image: '/assets/img/home&accessories.png' },
    { name: 'Women & Fashion', path: '/women-and-fashion', image: '/assets/img/women&fashion.png' },
    { name: 'Beauty', path: '/beauty', image: '/assets/img/beautylogo.png' },
    { name: 'Jewelry', path: '/jewelry', image: '/assets/img/jewelry.png' },
    { name: 'Watches', path: '/watches', image: '/assets/img/watches.png' },
    { name: 'Kitchen Appliances', path: '/kitchen-appliances', image: '/assets/img/kitchen appliances.png' },
    { name: 'Electronic Appliances', path: '/electronic-appliances', image: '/assets/img/electronics.png' },
    { name: 'Men', path: '/men', image: '/assets/img/men.png' },
  ];

  return (
    <div className="bg-gray-100 min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1 flex flex-col items-center">
        <div className="w-full py-6">
          <Carousel />
        </div>
        <section className="w-full max-w-7xl px-4 sm:px-6 lg:px-8 mt-8">
          <h2 className="text-3xl font-bold text-center mb-6">Categories</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {categories.map((category, index) => (
              <Link 
                to={category.path} 
                key={index} 
                className="bg-white p-4 rounded-lg shadow transition-transform transform hover:scale-105"
              >
                <img 
                  src={category.image} 
                  alt={category.name} 
                  className="h-40 w-full object-cover rounded-t-lg" 
                />
                <div className="mt-4">
                  <h3 className="w-full bg-ufone-orange text-white rounded-full py-3 px-8 uppercase font-bold text-xs transition-transform transform active:scale-95 mt-4 no-underline">
                    {category.name}
                  </h3>
                </div>
              </Link>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Home;
