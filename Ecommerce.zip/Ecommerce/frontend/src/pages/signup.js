import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Signup = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
  });
  const navigate = useNavigate();

  const { name, email, password } = formData;

  const onChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const onSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:5000/api/auth/register', formData);
      console.log(response.data);

      navigate('/login');
      toast.success('Registration successful!');
    } catch (error) {
      console.error('Registration error:', error.response?.data || error.message);

      if (error.response && error.response.data.errors) {
        toast.error(error.response.data.errors.map(err => err.msg).join(', '));
      } else {
        toast.error('An unexpected error occurred');
      }
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-md mx-auto bg-white rounded-lg shadow-md overflow-hidden md:max-w-md">
        <div className="md:flex">
          <div className="w-full p-3 px-6 py-10">
            <div className="text-center">
              <h1 className="text-gray-800 text-3xl font-semibold">Create Account</h1>
              <div className="flex items-center justify-center mt-4 mb-4">
                <span className="h-px bg-gray-300 w-16"></span>
                <span className="h-px bg-gray-300 w-16"></span>
              </div>
            </div>
            <form className="mt-8" onSubmit={onSubmit}>
              <input
                type="text"
                name="name"
                placeholder="Name"
                value={name}
                onChange={onChange}
                className="block w-full bg-gray-100 text-gray-800 border rounded-lg px-4 py-2 mb-4"
              />
              <input
                type="email"
                name="email"
                placeholder="Email"
                value={email}
                onChange={onChange}
                className="block w-full bg-gray-100 text-gray-800 border rounded-lg px-4 py-2 mb-4"
              />
              <input
                type="password"
                name="password"
                placeholder="Password"
                value={password}
                onChange={onChange}
                className="block w-full bg-gray-100 text-gray-800 border rounded-lg px-4 py-2 mb-4"
              />
              <button
                type="submit"
                className="w-full bg-ufone-orange text-white rounded-full py-3 px-8 uppercase font-bold text-xs transition-transform transform active:scale-95 mt-4 hover:bg-orange-700"
              >
                Sign Up
              </button>
            </form>
            <p className="mt-4 text-gray-600">
              Already have an account? <Link to="/login" className="text-red-500 hover:underline">Sign In</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Signup;
