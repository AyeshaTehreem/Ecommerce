/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'ufone-orange': '#f56c0d' // Ufone's orange color
      }
    },
  },
  plugins: [],
}
