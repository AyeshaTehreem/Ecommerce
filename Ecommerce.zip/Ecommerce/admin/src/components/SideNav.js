// src/components/SideNav.js
import React from 'react';
import { Link } from 'react-router-dom';
import './SideNav.css'; // Import CSS for styling

const SideNav = ({ categories }) => {
  return (
    <div className="side-nav">
      <h2>Categories</h2>
      <ul>
        {categories.map((category) => (
          <li key={category}>
            <Link to={`/admin/${category}`}>{category}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default SideNav;
