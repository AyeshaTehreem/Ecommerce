// src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import CategoryItems from './pages/CategoryItems';

import './components/AdminPanel.css'; // Import the CSS file

const App = () => {
  return (
    <Router>    
        <Routes>
          <Route path="/admin/:category" element={<CategoryItems />} />
          {/* Add other routes as needed */}
        </Routes>
    </Router>
  );
};

export default App;
