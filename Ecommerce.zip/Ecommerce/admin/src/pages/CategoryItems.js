import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import '../components/AdminPanel.css'; // Import the CSS file
import SideNav from '../components/SideNav'; // Import the SideNav component

const CategoryItems = () => {
  const { category } = useParams();
  const [items, setItems] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [newProduct, setNewProduct] = useState({
    name: '',
    picture: null,
    price: '',
    category: category || ''
  });

  const categories = [
    'Beauty',
    'Electronic Appliances',
    'Home & Accessories',
    'Jewelry',
    'Kitchen Appliances',
    'Men',
    'Watches',
    'Women & Fashion'
  ];

  useEffect(() => {
    fetchItems();
  }, [category]);

  const fetchItems = () => {
    axios.get(`http://localhost:5000/api/products?category=${category}`)
      .then(response => {
        console.log('Fetched items:', response.data);
        setItems(response.data);
      })
      .catch(error => console.error('Error fetching items:', error));
  };

  const handleDelete = (id) => {
    axios.delete(`http://localhost:5000/api/products/${id}`)
      .then(() => setItems(items.filter(item => item._id !== id)))
      .catch(error => console.error(error));
  };

  const handleAdd = async (e) => {
    e.preventDefault();
    console.log('Adding product:', newProduct);

    const formData = new FormData();
    formData.append('name', newProduct.name);
    formData.append('price', newProduct.price);
    formData.append('category', newProduct.category);

    if (newProduct.picture) {
      formData.append('picture', newProduct.picture);
    }

    try {
      const response = await axios.post('http://localhost:5000/api/products', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });
      console.log('Product added:', response.data);
      setShowModal(false);
      setNewProduct({ name: '', picture: null, price: '', category: category || '' });
      fetchItems();
    } catch (error) {
      console.error('Error adding product:', error);
    }
  };

  const handleFileChange = (e) => {
    setNewProduct({ ...newProduct, picture: e.target.files[0] });
  };

  const handleCategoryChange = (e) => {
    setNewProduct({ ...newProduct, category: e.target.value });
  };

  return (
    <div className="main-content">
      <SideNav categories={categories} /> {/* Add the SideNav component */}
      <div className="content">
        <button className="add-button" onClick={() => setShowModal(true)}>Add Item</button>
        {showModal && (
          <div className="modal">
            <form onSubmit={handleAdd}>
              <input
                type="text"
                placeholder="Product Name"
                value={newProduct.name}
                onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                required
              />
              <input
                type="file"
                onChange={handleFileChange}
                required
              />
              <input
                type="number"
                placeholder="Price"
                value={newProduct.price}
                onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })}
                required
              />
              <select
                value={newProduct.category}
                onChange={handleCategoryChange}
                required
              >
                <option value="">Select Category</option>
                {categories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
              <button type="submit">Add Product</button>
              <button type="button" onClick={() => setShowModal(false)}>Close</button>
            </form>
          </div>
        )}
        <div className="table-container">
          <table className="items-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Picture</th>
                <th>Price</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map(item => (
                <tr key={item._id}>
                  <td>{item.name}</td>
                  <td><img src={`http://localhost:5000/${item.picture}`} alt={item.name} className="item-picture" /></td>
                  <td>${item.price}</td>
                  <td><button onClick={() => handleDelete(item._id)}>Delete</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default CategoryItems;
