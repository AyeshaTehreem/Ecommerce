// src/pages/Products.js
import React from 'react';
import { Link } from 'react-router-dom';
import ProductList from '../components/ProductList'; // Add this line

const Products = () => {
  return (
    <div>
      <h1>Products</h1>
      <Link to="/add-product">Add Product</Link>
      <ProductList />
    </div>
  );
};

export default Products;
